// EthernetViewer1Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "EthernetViewer1.h"
#include "EthernetViewer1Dlg.h"
//
#include "SelectAdaptorDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEthernetViewer1Dlg dialog

CEthernetViewer1Dlg::CEthernetViewer1Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CEthernetViewer1Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CEthernetViewer1Dlg)
	m_EDIT_iCountInput = 0;
	m_EDIT_iCountOutput = 0;
	m_EDIT_iIpPacket = 0;
	m_EDIT_iEtcPacket = 0;
	m_EDIT_iArpPacket = 0;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CEthernetViewer1Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CEthernetViewer1Dlg)
	DDX_Control(pDX, IDC_LIST_Packetinfo, m_LIST_PacketInfo);
	DDX_Text(pDX, IDC_EDIT_CountInput, m_EDIT_iCountInput);
	DDX_Text(pDX, IDC_EDIT_CountOutput, m_EDIT_iCountOutput);
	DDX_Text(pDX, IDC_EDIT_IpPacket, m_EDIT_iIpPacket);
	DDX_Text(pDX, IDC_EDIT_EtcPacket, m_EDIT_iEtcPacket);
	DDX_Text(pDX, IDC_EDIT_ArpPacket, m_EDIT_iArpPacket);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CEthernetViewer1Dlg, CDialog)
	//{{AFX_MSG_MAP(CEthernetViewer1Dlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_SelectAdaptor, OnBUTTONSelectAdaptor)
	ON_BN_CLICKED(IDC_CHECK_Filter_IP, OnCHECKFilterIP)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEthernetViewer1Dlg message handlers

BOOL CEthernetViewer1Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	m_LIST_PacketInfo.InsertColumn(0,"��ȣ",LVCFMT_CENTER,40);
	m_LIST_PacketInfo.InsertColumn(1,"�߽� MAC �ּ�",LVCFMT_LEFT,150);
	m_LIST_PacketInfo.InsertColumn(2,"���� MAC �ּ�",LVCFMT_LEFT,150);
	m_LIST_PacketInfo.InsertColumn(3,"���� �������� ��ȣ",LVCFMT_LEFT,200);
	
	m_LIST_PacketInfo.SetExtendedStyle(LVS_EX_FULLROWSELECT);

	m_iFilter_IP = 0;
	//
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CEthernetViewer1Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CEthernetViewer1Dlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CEthernetViewer1Dlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CEthernetViewer1Dlg::OnBUTTONSelectAdaptor() 
{
	// TODO: Add your control notification handler code here
	CSelectAdaptorDlg *pDlg = new CSelectAdaptorDlg;
	
	if(pDlg->DoModal() != IDOK){
		delete pDlg;
		return;
	}	


	//��� ǥ�ÿ� list cntrol �ʱ�ȭ 
	m_LIST_PacketInfo.DeleteAllItems();

	if(pDlg->OpenAdaptor(m_iFilter_IP)){
		::AfxMessageBox("Adaptor open ���� ");

		pDlg->CloseAdaptor();
		delete pDlg;

		return;
	}


	//��Ŷ�� ȹ���Ͽ� list control�� ǥ�� 
#define MaxBufferLen 2048
	UpdateData(true);
	m_EDIT_iArpPacket =0;
	m_EDIT_iEtcPacket=0;
	m_EDIT_iIpPacket=0;
	for(int i=0; i<m_EDIT_iCountInput; i++){
		unsigned char arrTemp[MaxBufferLen];


		//��Ŷ�� �ϳ� ȹ���� . ������ return�Ǹ� ������ �߻��� ��.
		if(pDlg->Ncap(arrTemp, MaxBufferLen) < 0)
			continue;

		//�Ϸù�ȣ
		CString strNum;
		strNum.Format(_T("%d"),i);
		m_LIST_PacketInfo.InsertItem(LVIF_TEXT,i,strNum,0,0,0,0);

		//������ �ּ� 
		CString strDestMac;
		strDestMac.Format(_T("%02x %02x %02x - %02x %02x %02x"),arrTemp[0],arrTemp[1],arrTemp[2],arrTemp[3],arrTemp[4],arrTemp[5]);
		m_LIST_PacketInfo.SetItem(i,2,LVIF_TEXT,strDestMac,0,0,0,0);

		//�ٿ��� �ּ� 
		CString strSrcMack;
		strSrcMack.Format(_T("%02x %02x %02x - %02x %02x %02x"),arrTemp[6],arrTemp[7],arrTemp[8],arrTemp[9],arrTemp[10],arrTemp[11]);
		m_LIST_PacketInfo.SetItem(i,1,LVIF_TEXT,strSrcMack,0,0,0,0);

		//Ÿ�� 
		CString strType;
		CString strType2;
		unsigned int iTypeORlength = 
			pDlg->Twobytes_to_number(arrTemp[12],arrTemp[13]);
		strType.Format(_T("%02x %02x(Hex), %d(Decimal)"),arrTemp[12],arrTemp[13],iTypeORlength);

		strType2.Format(_T("%02x %02x"),arrTemp[12],arrTemp[13]);
		if(strType2 == "08 00") m_EDIT_iIpPacket++;
		else if(strType2 == "08 06") m_EDIT_iArpPacket++;
		else m_EDIT_iEtcPacket++;

		m_LIST_PacketInfo.SetItem(i,3,LVIF_TEXT,strType,0,0,0,0);
		
		m_EDIT_iCountOutput = i +1;
		UpdateData(false);
	}

	//����� �ڿ� ���� 
	pDlg->CloseAdaptor();

	//Ncap lib ���� 
	delete pDlg;

  
}

void CEthernetViewer1Dlg::OnCHECKFilterIP() 
{
	// TODO: Add your control notification handler code here
	if(m_iFilter_IP == 1)
		m_iFilter_IP = 0;
	else
		m_iFilter_IP = 1;
}
